import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();


        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Douthat State Park - Douthat State Park is a state park located in the Allegheny Mountains in Virginia. It is in Bath County and Alleghany County. The park is 4,545 acres (18 km�) total with a 50-acre (20 ha) lake.", new ImageIcon(getClass().getResource("/resources/Douthat_State_Park.jpg")));
        addDestinationNameAndPicture("2. Jasna Ski Resort - The largest Ski resort in Slovakia is located in the Low Tatras mountains and offers great conditions for winter sports for expert and beginner skiers.", new ImageIcon(getClass().getResource("/resources/Jasn�_Ski_Resort.jpg")));
        addDestinationNameAndPicture("3. Koronadal - Koronadal, officially the City of Koronadal (Hiligaynon: Dakbanwa sang Koronadal; Maguindanaon: Ingud nu Koronadal), and also known as Marbel, is a 3rd class component city and capital of the province of South Cotabato, Philippines. According to the 2020 census, it has a population of 195,398 people.", new ImageIcon(getClass().getResource("/resources/Koronadal.jpg")));
        addDestinationNameAndPicture("4. Namchi - Namchi is fast becoming a tourist spot and pilgrimage centre. The Namchi Monastery, Ralang Monastery and Tendong Hill are local Buddhist pilgrimage centres. The world's largest statue (at 118 feet) of the Buddhist Padmasambhava, also known as Guru Rinpoche, the patron saint of Sikkim, is on the Samdruptse hill (The Wish Fulfilling hill) opposite Namchi. ", new ImageIcon(getClass().getResource("/resources/Namchi.jpg")));
        addDestinationNameAndPicture("5. Terre de Haut Island - Terre-de-Haut Island (in Creole:T�d�ho, also formerly known as Petite Martinique) is the easternmost island in the �les des Saintes , part of the archipelago of Guadeloupe.", new ImageIcon(getClass().getResource("/resources/Terre-de-Haut_Island_Guadeloupe.jpg")));
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);

        list.setCellRenderer(renderer);
        //Added the background color
        list.setBackground(Color.CYAN);

        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}